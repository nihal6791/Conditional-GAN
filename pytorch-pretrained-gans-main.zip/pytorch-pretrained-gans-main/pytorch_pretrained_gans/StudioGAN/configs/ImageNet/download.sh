# SAGAN
# https://drive.google.com/file/d/1exrZloM2bHYJyU5_v9XUMlNcy5TA6gMN/view?usp=sharing
cd SAGAN
gdown --id 1exrZloM2bHYJyU5_v9XUMlNcy5TA6gMN
cd ..

# SNGAN
# https://drive.google.com/file/d/1L4Jk9v_vRojdj9ZpLBak8OxoahdsX5yn/view?usp=sharing
cd SNGAN
gdown --id 1L4Jk9v_vRojdj9ZpLBak8OxoahdsX5yn
cd ..

# BigGAN2048
# https://drive.google.com/file/d/14VIJUsYcItZrfNk_PcjglNXH_sPyd504/view?usp=sharing
cd BigGAN2048
gdown --id 16tZIHrXFYFM6mXmEF-4YA7vO1D-s7meq
cd ..

# ContraGAN256
# https://drive.google.com/file/d/15ipVwbQpncc678tGdT7VsDcFCstUpP1n/view?usp=sharing
cd ContraGAN256
gdown --id 15ipVwbQpncc678tGdT7VsDcFCstUpP1n
cd ..
